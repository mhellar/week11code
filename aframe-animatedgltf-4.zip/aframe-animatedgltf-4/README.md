# aframe-boilerplate

aframe-boilerplate.

Built with [A-Frame](https://aframe.io).

## Setup

```sh
npm install
npm run start
```
